import json
import pathlib
from typing import Union, List, Tuple, Type

import numpy as np
import pandas as pd

from icare import check_errors


def read_file_to_string(file: Union[str, pathlib.Path]) -> str:
    with open(file, mode="r") as f:
        return " ".join(f.read().splitlines())


def read_file_to_dict(file: Union[str, pathlib.Path]) -> dict:
    with open(file, mode="r") as f:
        return json.load(f)


def read_file_to_dataframe(file: Union[str, pathlib.Path], allow_integers: bool = True) -> pd.DataFrame:
    with open(file, mode="r") as f:
        header = f.readline().split(",")
        first_row = f.readline().split(",")

    dtype = dict()
    for variable, value in zip(header, first_row):
        if (value.startswith('"') or value.startswith("'")) and \
                (value.endswith('"') or value.endswith("'")):
            dtype[variable] = object

    df = pd.read_csv(file, dtype=dtype)

    if not allow_integers:
        for col in df.columns:
            # to support nullable integer types
            if np.issubdtype(df[col].dtype, int):
                df[col] = df[col].astype(float)

    if "id" in df.columns:
        df.set_index("id", inplace=True)

    return df


def read_file_to_dataframe_given_dtype(file, dtype) -> pd.DataFrame:
    header = pd.read_csv(file, nrows=1).columns
    if "id" in header:
        if isinstance(dtype, dict) and "id" not in dtype:
            dtype = {"id": str, **dtype}
        else:
            dtype = {"id": str, **{col: dtype for col in header if col != "id"}}

    df = pd.read_csv(file, dtype=dtype)

    if "id" in df.columns:
        df.set_index("id", inplace=True)

    return df


def set_age_intervals(age_start: Union[int, List[int]], age_interval_length: Union[int, List[int]],
                      num_samples_profile: int, profile_name: str) -> Tuple[List[int], List[int]]:
    if isinstance(age_start, int):
        age_start = [age_start] * num_samples_profile

    if isinstance(age_interval_length, int):
        age_interval_length = [age_interval_length] * num_samples_profile

    if len(age_start) != num_samples_profile or len(age_interval_length) != num_samples_profile:
        raise ValueError(f"ERROR: the number of values in 'apply_age_start' and 'apply_age_interval_length', "
                         f"and the number of rows in '{profile_name}' must match.")

    check_errors.check_age_intervals(age_start, age_interval_length)

    return age_start, age_interval_length
